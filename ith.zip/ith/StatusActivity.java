package com.example.ith;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class StatusActivity extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private EditText editTextDeskripsi;
    private TextView buttonAjukan;
    private SharedPreferences sharedPreferences;
    private String nip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_status);

        // Menambahkan tombol back di toolbar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Ambil NIP dari SharedPreferences atau Intent
        nip = getIntent().getStringExtra("NIP");
        if (nip == null) {
            Log.e("StatusActivity", "NIP tidak ditemukan");
            Toast.makeText(this, "Kesalahan: NIP tidak ditemukan", Toast.LENGTH_SHORT).show();
            // Mengarahkan ke home_dosen jika NIP tidak ditemukan
            startActivity(new Intent(StatusActivity.this, home_dosen.class));
            finish();
            return;
        }

        ImageView profil_dosen = findViewById(R.id.profil_icon);
        ImageView progres_dosen = findViewById(R.id.progres_icon);
        ImageView home_dosen = findViewById(R.id.home_icon);
        ImageView jadwal_dosen = findViewById(R.id.jadwal_icon);

        jadwal_dosen.setOnClickListener(view -> {
            String nipFromPrefs = sharedPreferences.getString("NIP", null); // Ambil NIP dari SharedPreferences
            if (nipFromPrefs != null) {
                Intent intent = new Intent(StatusActivity.this, jadwal_dosen.class);
                intent.putExtra("NIP", nipFromPrefs); // Kirimkan NIP ke progres_dosen
                startActivity(intent);
            }
        });

        home_dosen.setOnClickListener(view -> {
            String nipFromPrefs = sharedPreferences.getString("NIP", null); // Ambil NIP dari SharedPreferences
            if (nipFromPrefs != null) {
                Intent intent = new Intent(StatusActivity.this, home_dosen.class);
                intent.putExtra("NIP", nipFromPrefs);
                startActivity(intent);
            }
        });

        // Mengatur tombol profil dosen
        profil_dosen.setOnClickListener(view -> {
            String nipFromPrefs = sharedPreferences.getString("NIP", null); // Ambil NIP dari SharedPreferences
            if (nipFromPrefs != null) {
                Intent intent = new Intent(StatusActivity.this, profil_dosen.class);
                intent.putExtra("NIP", nipFromPrefs); // Kirimkan NIP ke profil_dosen
                startActivity(intent);
            }
        });

        progres_dosen.setOnClickListener(view -> {
            String nipFromPrefs = sharedPreferences.getString("NIP", null); // Ambil NIP dari SharedPreferences
            if (nipFromPrefs != null) {
                Intent intent = new Intent(StatusActivity.this, progres_dosen.class);
                intent.putExtra("NIP", nipFromPrefs); // Kirimkan NIP ke progres_dosen
                startActivity(intent);
            }
        });

        // Inisialisasi referensi Firebase
        databaseReference = FirebaseDatabase.getInstance().getReference("/users/dosen/" + nip);

        // Inisialisasi elemen UI
        editTextDeskripsi = findViewById(R.id.tambah_deskripsi);
        buttonAjukan = findViewById(R.id.button_ajukan);

        // Inisialisasi TextView untuk tindakan status
        initStatusActions();

        // Tombol ajukan deskripsi
        buttonAjukan.setOnClickListener(view -> {
            String deskripsi = editTextDeskripsi.getText().toString().trim();
            if (!deskripsi.isEmpty()) {
                addDeskripsiWithDateAndDay(deskripsi);
            } else {
                Toast.makeText(this, "Deskripsi tidak boleh kosong", Toast.LENGTH_SHORT).show();
            }
        });

        // Tombol hapus status dan deskripsi
        TextView buttonClear = findViewById(R.id.clear);
        buttonClear.setOnClickListener(view -> {
            // Clear text description
            editTextDeskripsi.setText("");

            // Reset status values
            resetStatusValues();

            Toast.makeText(this, "Status dan deskripsi dihapus", Toast.LENGTH_SHORT).show();
        });

        // Navigasi melalui ikon
        setupNavigationIcons();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void initStatusActions() {
        findViewById(R.id.kampus1).setOnClickListener(view -> updateData("lokasi", "Kampus 1"));
        findViewById(R.id.kampus2).setOnClickListener(view -> updateData("lokasi", "Kampus 2"));
        findViewById(R.id.siap_megajar).setOnClickListener(view -> updateData("bimbingan", "Siap Mengajar"));
        findViewById(R.id.siap_lakukan_bimbingan).setOnClickListener(view -> updateData("bimbingan", "Siap Bimbingan"));
        findViewById(R.id.berhalangan).setOnClickListener(view -> updateData("status", "Berhalangan"));
        findViewById(R.id.terlambat).setOnClickListener(view -> updateData("status", "siap"));
        findViewById(R.id.online).setOnClickListener(view -> updateData("status2", "Online"));
        findViewById(R.id.off).setOnClickListener(view -> updateData("status2", "Off"));
    }

    private void setupNavigationIcons() {
        ImageView imageViewKembali = findViewById(R.id.back);
        imageViewKembali.setOnClickListener(view -> finish());

        ImageView homeDosenButton = findViewById(R.id.home_icon);
        homeDosenButton.setOnClickListener(view -> {
            Intent homeIntent = new Intent(this, home_dosen.class);
            startActivity(homeIntent);
        });

        ImageView profilDosenButton = findViewById(R.id.profil_icon);
        profilDosenButton.setOnClickListener(view -> {
            Intent profilIntent = new Intent(this, profil_dosen.class);
            profilIntent.putExtra("NIP", nip); // Mengirimkan NIP ke profil_dosen
            startActivity(profilIntent);
        });
    }

    private void updateData(String key, String value) {
        databaseReference.child(key).setValue(value)
                .addOnSuccessListener(aVoid -> Toast.makeText(this, key + " diperbarui: " + value, Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(this, "Gagal memperbarui " + key, Toast.LENGTH_SHORT).show());
    }

    private void resetStatusValues() {
        databaseReference.child("lokasi").setValue("null");  // Reset lokasi
        databaseReference.child("bimbingan").setValue("null");  // Reset bimbingan
        databaseReference.child("status").setValue("null");  // Reset status
        databaseReference.child("status2").setValue("null");  // Reset status2
    }

    private void addDeskripsiWithDateAndDay(String deskripsiText) {
        DatabaseReference newDeskripsiRef = databaseReference.child("deskripsi").push();

        String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Calendar.getInstance().getTime());
        String currentDay = new SimpleDateFormat("EEEE", Locale.getDefault()).format(Calendar.getInstance().getTime());

        Deskripsi deskripsi = new Deskripsi(newDeskripsiRef.getKey(), deskripsiText, currentDate, currentDay);

        newDeskripsiRef.setValue(deskripsi)
                .addOnSuccessListener(aVoid -> Toast.makeText(this, "Deskripsi berhasil diajukan", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(this, "Gagal mengajukan deskripsi", Toast.LENGTH_SHORT).show());
    }

    public static class Deskripsi {
        private String id;
        private String deskripsi;
        private String tanggal;
        private String hari;

        public Deskripsi() {}

        public Deskripsi(String id, String deskripsi, String tanggal, String hari) {
            this.id = id;
            this.deskripsi = deskripsi;
            this.tanggal = tanggal;
            this.hari = hari;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getDeskripsi() {
            return deskripsi;
        }

        public void setDeskripsi(String deskripsi) {
            this.deskripsi = deskripsi;
        }

        public String getTanggal() {
            return tanggal;
        }

        public void setTanggal(String tanggal) {
            this.tanggal = tanggal;
        }

        public String getHari() {
            return hari;
        }

        public void setHari(String hari) {
            this.hari = hari;
        }
    }
}
