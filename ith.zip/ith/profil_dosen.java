package com.example.ith;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class profil_dosen extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private TextView textViewNama;
    private EditText editTextNick, editTextNip;
    private TextView buttonEditProfile;
    private String nip; // NIP dosen yang dikirim dari Home Dosen
    private DatabaseReference databaseReference;
    private boolean isEditMode = false; // Mode untuk mengatur apakah sedang dalam mode edit

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_dosen);

        // Inisialisasi SharedPreferences
        sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);

        // Ambil NIP dari Intent
        nip = getIntent().getStringExtra("NIP");
        if (nip == null || nip.isEmpty()) {
            Toast.makeText(this, "NIP tidak ditemukan!", Toast.LENGTH_SHORT).show();
            finish(); // Tutup Activity jika NIP tidak ditemukan
            return;
        }

        ImageView jadwal_dosen = findViewById(R.id.jadwal_icon);

        jadwal_dosen.setOnClickListener(view -> {
            String nipFromPrefs = sharedPreferences.getString("NIP", null); // Ambil NIP dari SharedPreferences
            if (nipFromPrefs != null) {
                Intent intent = new Intent(profil_dosen.this, jadwal_dosen.class);
                intent.putExtra("NIP", nipFromPrefs); // Kirimkan NIP ke progres_dosen
                startActivity(intent);
            }
        });

        // Inisialisasi elemen UI
        textViewNama = findViewById(R.id.nama_profil);
        editTextNick = findViewById(R.id.user_name);
        editTextNip = findViewById(R.id.user_nip);
        buttonEditProfile = findViewById(R.id.button_editP);
        ImageView homeIcon = findViewById(R.id.home_icon);
        ImageView progresIcon = findViewById(R.id.progres_icon);
        TextView logoutButton = findViewById(R.id.logoutButton);

        // Atur EditText agar tidak dapat diedit saat pertama kali
        toggleEditMode(false);

        // Ambil data dari Firebase berdasarkan NIP
        loadDataFromFirebase();

        // Logika untuk tombol Edit Profil
        buttonEditProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isEditMode) {
                    // Simpan data ke Firebase jika sedang dalam mode edit
                    saveDataToFirebase();
                } else {
                    // Aktifkan mode edit
                    toggleEditMode(true);
                }
            }
        });

        // Logika klik untuk kembali ke Home Dosen
        homeIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(profil_dosen.this, home_dosen.class);
                startActivity(intent);
                finish(); // Tutup activity ini setelah pindah
            }
        });

        // Logika klik untuk membuka Progres Dosen
        progresIcon.setOnClickListener(view -> {
            String nipFromPrefs = sharedPreferences.getString("NIP", null); // Ambil NIP dari SharedPreferences
            if (nipFromPrefs != null) {
                Intent intent = new Intent(profil_dosen.this, progres_dosen.class);
                intent.putExtra("NIP", nipFromPrefs); // Kirimkan NIP ke progres_dosen
                startActivity(intent);
            } else {
                Toast.makeText(profil_dosen.this, "NIP tidak ditemukan di sesi pengguna!", Toast.LENGTH_SHORT).show();
            }
        });

        // Logika untuk tombol logout
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearSessionData();
                Intent intent = new Intent(profil_dosen.this, ITHRegis.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Menghapus semua aktivitas sebelumnya
                startActivity(intent);
                finish(); // Menutup aktivitas ini
            }
        });
    }

    // Fungsi untuk membersihkan sesi pengguna
    private void clearSessionData() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear(); // Menghapus semua data di SharedPreferences
        editor.apply();
    }

    // Fungsi untuk mengambil data dari Firebase
    private void loadDataFromFirebase() {
        databaseReference = FirebaseDatabase.getInstance().getReference("users/dosen").child(nip);

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Ambil data dari Firebase
                    String nama = snapshot.child("nama").getValue(String.class);
                    String nick = snapshot.child("nick").getValue(String.class);

                    // Tampilkan data di UI
                    textViewNama.setText(nama != null ? nama : "Nama tidak tersedia");
                    editTextNick.setText(nick != null ? nick : "");
                    editTextNip.setText(nip != null ? nip : "");

                    // Simpan NIP ke SharedPreferences
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("NIP", nip);
                    editor.apply();
                } else {
                    Toast.makeText(profil_dosen.this, "Data untuk NIP ini tidak ditemukan", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(profil_dosen.this, "Gagal memuat data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Fungsi untuk menyimpan data ke Firebase
    private void saveDataToFirebase() {
        String updatedNick = editTextNick.getText().toString();
        String updatedNip = editTextNip.getText().toString();

        if (!updatedNick.isEmpty() && !updatedNip.isEmpty()) {
            databaseReference.child("nick").setValue(updatedNick);
            databaseReference.child("nip").setValue(updatedNip);

            Toast.makeText(profil_dosen.this, "Data berhasil diperbarui", Toast.LENGTH_SHORT).show();
            toggleEditMode(false); // Kembali ke mode tampilan
        } else {
            Toast.makeText(profil_dosen.this, "Nick dan NIP tidak boleh kosong", Toast.LENGTH_SHORT).show();
        }
    }

    // Fungsi untuk mengatur mode edit
    private void toggleEditMode(boolean enable) {
        if (enable) {
            editTextNick.setEnabled(true);
            editTextNip.setEnabled(true);
            buttonEditProfile.setText("Simpan");
        } else {
            editTextNick.setEnabled(false);
            editTextNip.setEnabled(false);
            buttonEditProfile.setText("Edit Profil");
        }
        isEditMode = enable;
    }
}
