package com.example.ith;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class add_dosen_Aktivity extends AppCompatActivity {
    private EditText etNip, etNama, etNick, etPassword, etFotoUrl;
    private Button btnAddDosen;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_dosen);

        etNip = findViewById(R.id.editNIP);
        etNama = findViewById(R.id.editNama);
        etNick = findViewById(R.id.editNick);
        etPassword = findViewById(R.id.editPassword);
        etFotoUrl = findViewById(R.id.editPhotoUrl);
        btnAddDosen = findViewById(R.id.buttonSimpan);

        databaseReference = FirebaseDatabase.getInstance().getReference("users/dosen");

        btnAddDosen.setOnClickListener(view -> {
            String nip = etNip.getText().toString();
            String nama = etNama.getText().toString();
            String nick = etNick.getText().toString();
            String password = etPassword.getText().toString();
            String fotoUrl = etFotoUrl.getText().toString();

            if (TextUtils.isEmpty(nip) || TextUtils.isEmpty(nama) || TextUtils.isEmpty(nick) ||
                    TextUtils.isEmpty(password) || TextUtils.isEmpty(fotoUrl)) {
                Toast.makeText(add_dosen_Aktivity.this, "Semua field harus diisi!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Buat objek dosen
            Dosen dosen = new Dosen(nama, nick, nip, password, fotoUrl, "dosen");

            // Tambahkan ke database Firebase
            databaseReference.child(nip).setValue(dosen)
                    .addOnSuccessListener(unused -> Toast.makeText(add_dosen_Aktivity.this, "Dosen berhasil ditambahkan!", Toast.LENGTH_SHORT).show())
                    .addOnFailureListener(e -> Toast.makeText(add_dosen_Aktivity.this, "Gagal menambahkan dosen: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        });
    }

    // Model Dosen
    public static class Dosen {
        private String nama, nick, nip, pass_dosen, poto, role;

        public Dosen() {
            // Default constructor
        }

        public Dosen(String nama, String nick, String nip, String pass_dosen, String poto, String role) {
            this.nama = nama;
            this.nick = nick;
            this.nip = nip;
            this.pass_dosen = pass_dosen;
            this.poto = poto;
            this.role = role;
        }

        // Getter dan Setter
        public String getNama() {
            return nama;
        }

        public void setNama(String nama) {
            this.nama = nama;
        }

        public String getNick() {
            return nick;
        }

        public void setNick(String nick) {
            this.nick = nick;
        }

        public String getNip() {
            return nip;
        }

        public void setNip(String nip) {
            this.nip = nip;
        }

        public String getPass_dosen() {
            return pass_dosen;
        }

        public void setPass_dosen(String pass_dosen) {
            this.pass_dosen = pass_dosen;
        }

        public String getPoto() {
            return poto;
        }

        public void setPoto(String poto) {
            this.poto = poto;
        }

        public String getRole() {
            return role;
        }

        public void setRole(String role) {
            this.role = role;
        }
    }
}
