//package com.example.ith;
//
//import android.os.Bundle;
//import android.view.View;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//
//import java.util.HashMap;
//import java.util.Map;
//
//public class homebarang extends AppCompatActivity {
//
//    private EditText editTextNamaBarang, editTextJumlahBarang, editTextHargaBarang, editTextPajak, editTextDiskon;
//    private Button buttonBayar, buttonHapusSemua;
//    private TextView textViewTotalBayar, textViewDaftarPembelian;
//
//    private DatabaseReference databaseBarang;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.tugas5);
//
//        // Firebase Database
//        databaseBarang = FirebaseDatabase.getInstance().getReference("Barang");
//
//        // Inisialisasi Views
//        editTextNamaBarang = findViewById(R.id.editTextNamaBarang);
//        editTextJumlahBarang = findViewById(R.id.editTextJumlahBarang);
//        editTextHargaBarang = findViewById(R.id.editTextHargaBarang);
//        editTextPajak = findViewById(R.id.editTextPajak);
//        editTextDiskon = findViewById(R.id.editTextDiskon);
//
//        buttonBayar = findViewById(R.id.buttonBayar);
//        buttonHapusSemua = findViewById(R.id.buttonHapusSemua);
//
//        textViewTotalBayar = findViewById(R.id.textViewTotalBayar);
//        textViewDaftarPembelian = findViewById(R.id.textViewDaftarPembelian);
//
//        // Listener tombol
//        buttonBayar.setOnClickListener(v -> simpanAtauUpdateData());
//        buttonHapusSemua.setOnClickListener(v -> hapusSemuaData());
//    }
//
//    private void simpanAtauUpdateData() {
//        String namaBarang = editTextNamaBarang.getText().toString();
//        int jumlahBarang = Integer.parseInt(editTextJumlahBarang.getText().toString());
//        double hargaBarang = Double.parseDouble(editTextHargaBarang.getText().toString());
//        double pajak = Double.parseDouble(editTextPajak.getText().toString());
//        double diskon = Double.parseDouble(editTextDiskon.getText().toString());
//
//        // Hitung total
//        double total = hargaBarang * jumlahBarang;
//        total += total * (pajak / 100); // Menambah pajak
//        total -= total * (diskon / 100); // Mengurangi diskon
//
//        // Data disimpan di "latestBarang" (akan diupdate setiap kali tombol ditekan)
//        Map<String, Object> data = new HashMap<>();
//        data.put("namaBarang", namaBarang);
//        data.put("jumlah", jumlahBarang);
//        data.put("harga", hargaBarang);
//        data.put("pajak", pajak);
//        data.put("diskon", diskon);
//        data.put("total", total);
//
//        databaseBarang.child("latestBarang").setValue(data)
//                .addOnSuccessListener(aVoid -> {
//                    textViewTotalBayar.setText("Total: Rp" + total);
//                    textViewDaftarPembelian.setText("Barang: " + namaBarang + ", Total: Rp" + total);
//                    Toast.makeText(homebarang.this, "Data berhasil disimpan/diupdate!", Toast.LENGTH_SHORT).show();
//                })
//                .addOnFailureListener(e -> Toast.makeText(homebarang.this, "Gagal menyimpan data!", Toast.LENGTH_SHORT).show());
//    }
//
//    private void hapusSemuaData() {
//        databaseBarang.child("latestBarang").removeValue()
//                .addOnSuccessListener(aVoid -> {
//                    textViewTotalBayar.setText("Total: Rp0");
//                    textViewDaftarPembelian.setText("Daftar Pembelian:");
//                    Toast.makeText(this, "Data berhasil dihapus!", Toast.LENGTH_SHORT).show();
//                })
//                .addOnFailureListener(e -> Toast.makeText(this, "Gagal menghapus data!", Toast.LENGTH_SHORT).show());
//    }
//}
