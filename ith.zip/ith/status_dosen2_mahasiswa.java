package com.example.ith;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class status_dosen2_mahasiswa extends AppCompatActivity {

    // Mendefinisikan referensi Firebase
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("/users/dosen/0008029503");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_dosen2_mahasiswa);

        // Menginisialisasi tampilan UI
        TextView namaDosen = findViewById(R.id.namaDosen);
        TextView siapMegajar = findViewById(R.id.siap_megajar);
        TextView kampus1 = findViewById(R.id.kampus1);
        TextView bimbinganTextView = findViewById(R.id.bimbingan);
        TextView deskripsiTextView = findViewById(R.id.textView3);
        ImageView dosenImageView = findViewById(R.id.profilicon_status); // ImageView untuk foto dosen

        // Tombol kembali ke halaman HomeActivity
        ImageView back = findViewById(R.id.back);
        back.setOnClickListener(view -> startActivity(new Intent(status_dosen2_mahasiswa.this, HomeActivity.class)));

        // Mendapatkan data deskripsi secara real-time
        databaseReference.child("deskripsi").orderByKey().limitToLast(1).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String deskripsi = null;
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    deskripsi = snapshot.child("deskripsi").getValue(String.class);
                }

                Log.d("FirebaseData", "Deskripsi terbaru: " + deskripsi);

                if (deskripsi != null) {
                    deskripsiTextView.setText(deskripsi);
                } else {
                    deskripsiTextView.setText("Deskripsi tidak tersedia");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("FirebaseError", "Terjadi kesalahan saat memuat data: " + databaseError.getMessage());
            }
        });

        // Mendapatkan data lainnya (nama, status, kampus, bimbingan, foto)
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String nama = dataSnapshot.child("nama").getValue(String.class);
                String status = dataSnapshot.child("status").getValue(String.class);
                String kampus = dataSnapshot.child("lokasi").getValue(String.class);
                String bimbinganData = dataSnapshot.child("bimbingan").getValue(String.class);
                String fotoUrl = dataSnapshot.child("poto").getValue(String.class);

                // Menampilkan data di TextView
                if (nama != null) {
                    namaDosen.setText(nama);
                } else {
                    namaDosen.setText("Nama tidak tersedia");
                }

                if (status != null) {
                    siapMegajar.setText(status);
                } else {
                    siapMegajar.setText("Status tidak tersedia");
                }

                if (kampus != null) {
                    kampus1.setText(kampus);
                } else {
                    kampus1.setText("Kampus tidak tersedia");
                }

                if (bimbinganData != null) {
                    bimbinganTextView.setText(bimbinganData);
                } else {
                    bimbinganTextView.setText("Bimbingan tidak tersedia");
                }


                if (fotoUrl != null) {
                    Glide.with(status_dosen2_mahasiswa.this)
                            .load(fotoUrl)
                            .into(dosenImageView);
                } else {
                    dosenImageView.setImageResource(R.drawable.example_pic); // Gambar default jika URL kosong
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("FirebaseError", "Terjadi kesalahan saat memuat data: " + databaseError.getMessage());
            }
        });
    }
}
