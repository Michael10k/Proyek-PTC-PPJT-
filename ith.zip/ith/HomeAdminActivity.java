package com.example.ith;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class HomeAdminActivity extends AppCompatActivity {

    private DatabaseReference mDatabase; // Referensi Firebase Database
    private GridLayout gridLayout;      // Layout untuk daftar dosen
    private EditText searchBar;         // EditText untuk pencarian
    private String selectedDosenKey = null; // Variabel untuk menyimpan key dosen yang dipilih

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_admin);

        // Inisialisasi Firebase Database
        mDatabase = FirebaseDatabase.getInstance().getReference("/users/dosen");

        // Inisialisasi GridLayout dan EditText untuk pencarian
        gridLayout = findViewById(R.id.gridLayoutDosen);
        searchBar = findViewById(R.id.search_bar);

        // Menambahkan TextWatcher pada searchBar
        searchBar.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                String query = charSequence.toString().trim();
                loadDosenFromFirebase(query); // Panggil fungsi loadDosen dengan query
            }

            @Override
            public void afterTextChanged(android.text.Editable editable) {}
        });

        // Memuat data dosen dari Firebase (tanpa filter)
        loadDosenFromFirebase("");

        // Tombol hapus
        ImageView deleteButton = findViewById(R.id.delete_button);
        deleteButton.setOnClickListener(v -> {
            if (selectedDosenKey != null) {
                showDeleteConfirmationDialog(); // Menampilkan konfirmasi sebelum menghapus
            } else {
                Toast.makeText(HomeAdminActivity.this, "Pilih nama dosen terlebih dahulu sebelum menghapus.", Toast.LENGTH_SHORT).show();
            }
        });

        // Tombol tambah dosen
        ImageView addButton = findViewById(R.id.tombolTambahDosen);
        addButton.setOnClickListener(v -> showAddDosenDialog());

        ImageView logoutButton = findViewById(R.id.logout_Button);
        logoutButton.setOnClickListener(v -> {
            Intent intent = new Intent(HomeAdminActivity.this, ITHRegis.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        });
    }

    // Fungsi untuk memuat data dosen dari Firebase dengan query case-insensitive
    private void loadDosenFromFirebase(String query) {
        String queryUpperCase = query.toUpperCase(); // Menggunakan huruf besar untuk pencarian case-insensitive

        mDatabase.orderByChild("nick")
                .startAt(queryUpperCase)
                .endAt(queryUpperCase + "\uf8ff")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        gridLayout.removeAllViews(); // Bersihkan GridLayout sebelum memperbarui data

                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            String namaDosen = snapshot.child("nick").getValue(String.class);
                            String photoUrl = snapshot.child("poto").getValue(String.class);
                            String key = snapshot.getKey();

                            if (namaDosen != null && key != null) {
                                addDosenToGrid(namaDosen, key, photoUrl);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(HomeAdminActivity.this, "Gagal memuat data dosen.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    // Fungsi untuk menambahkan dosen ke GridLayout
    private void addDosenToGrid(String namaDosen, String key, String photoUrl) {
        LinearLayout newDosenLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.list_item, null);

        // Tetapkan nama dosen pada TextView
        TextView textView = newDosenLayout.findViewById(R.id.nama1);
        textView.setText(namaDosen);

        // Tetapkan foto dosen pada ImageView
        ImageView imageView = newDosenLayout.findViewById(R.id.profil1);

        if (photoUrl != null && !photoUrl.isEmpty()) {
            Glide.with(this).load(photoUrl).placeholder(R.drawable.shape_cari).into(imageView);
        } else {
            imageView.setImageResource(R.drawable.shape_cari);
        }

        // Atur listener klik pada nama dosen
        newDosenLayout.setOnClickListener(v -> {
            selectedDosenKey = key;
            Toast.makeText(HomeAdminActivity.this, "Dosen dipilih: " + namaDosen, Toast.LENGTH_SHORT).show();
        });

        // Tambahkan layout ke GridLayout
        gridLayout.addView(newDosenLayout);
    }

    private void showAddDosenDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(HomeAdminActivity.this);
        builder.setTitle("Tambah Dosen");

        View dialogView = getLayoutInflater().inflate(R.layout.add_dosen, null);
        builder.setView(dialogView);

        final EditText inputNip = dialogView.findViewById(R.id.editNIP);
        final EditText inputNama = dialogView.findViewById(R.id.editNama);
        final EditText inputPassword = dialogView.findViewById(R.id.editPassword);
        final EditText inputNick = dialogView.findViewById(R.id.editNick);
        final EditText inputPhotoUrl = dialogView.findViewById(R.id.editPhotoUrl);

        builder.setPositiveButton("Tambah", (dialog, id) -> {
            String nip = inputNip.getText().toString().trim();
            String nama = inputNama.getText().toString().trim();
            String password = inputPassword.getText().toString().trim();
            String nick = inputNick.getText().toString().trim();
            String photoUrl = inputPhotoUrl.getText().toString().trim();

            if (!nip.isEmpty() && !nama.isEmpty() && !password.isEmpty() && !nick.isEmpty()) {
                // Konversi URL Google Drive ke direct link sebelum disimpan
                String directPhotoUrl = convertToDirectLink(photoUrl);
                tambahDosenKeFirebase(nip, nama, password, nick, directPhotoUrl);
            } else {
                Toast.makeText(HomeAdminActivity.this, "Semua kolom harus diisi.", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Batal", (dialog, id) -> dialog.cancel());
        builder.show();
    }

    // Fungsi untuk mengonversi URL Google Drive menjadi direct link
    private String convertToDirectLink(String fileUrl) {
        // Memeriksa apakah URL mengarah ke Google Drive
        if (fileUrl.contains("drive.google.com")) {
            // Ubah URL Google Drive menjadi direct link yang bisa diakses
            return fileUrl.replace("https://drive.google.com/file/d/", "https://drive.google.com/uc?id=")
                    .replace("/view?usp=sharing", "")
                    .replace("/view?usp=drivesdk", "");
        }
        // Kembalikan URL jika bukan dari Google Drive
        return fileUrl;
    }


    private void tambahDosenKeFirebase(String nip, String nama, String pass_dosen, String nick, String photoUrl) {
        DatabaseReference dosenRef = mDatabase.child(nip);

        HashMap<String, String> dosenMap = new HashMap<>();
        dosenMap.put("nip", nip);
        dosenMap.put("nama", nama);
        dosenMap.put("pass_dosen", pass_dosen);
        dosenMap.put("nick", nick);
        dosenMap.put("poto", photoUrl);
        dosenMap.put("role", "dosen");

        dosenRef.setValue(dosenMap).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(HomeAdminActivity.this, "Dosen berhasil ditambahkan.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(HomeAdminActivity.this, "Gagal menambah dosen.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showDeleteConfirmationDialog() {
        new AlertDialog.Builder(HomeAdminActivity.this)
                .setMessage("Apakah Anda yakin ingin menghapus dosen ini?")
                .setCancelable(false)
                .setPositiveButton("Ya", (dialog, id) -> deleteDosen(selectedDosenKey))
                .setNegativeButton("Tidak", null)
                .show();
    }

    private void deleteDosen(String key) {
        mDatabase.child(key).removeValue().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(HomeAdminActivity.this, "Dosen berhasil dihapus.", Toast.LENGTH_SHORT).show();
                selectedDosenKey = null;
            } else {
                Toast.makeText(HomeAdminActivity.this, "Gagal menghapus dosen.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
