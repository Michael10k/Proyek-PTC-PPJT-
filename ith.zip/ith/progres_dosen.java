package com.example.ith;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class progres_dosen extends AppCompatActivity {

    private LinearLayout progresLayout;
    private DatabaseReference databaseReferenceProgres;
    private String nip;  // NIP yang dikirim melalui Intent

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progres_dosen);

        // Mengambil nip dari Intent
        nip = getIntent().getStringExtra("NIP");

        if (nip == null || nip.isEmpty()) {
            Toast.makeText(this, "NIP tidak ditemukan!", Toast.LENGTH_SHORT).show();
            finish(); // Tutup Activity jika NIP tidak ditemukan
            return;
        }

        // Initialize layout untuk progres
        progresLayout = findViewById(R.id.progres_dosen);

        // Initialize Icons
        ImageView profil_dosen = findViewById(R.id.profil_icon);
        ImageView jadwal_dosen = findViewById(R.id.jadwal_icon);
        ImageView home_dosen = findViewById(R.id.home_icon);

        // Set onClick listeners untuk navigasi
        home_dosen.setOnClickListener(view -> {
            Intent intent = new Intent(progres_dosen.this, home_dosen.class);
            intent.putExtra("NIP", nip); // Kirim NIP ke home_dosen
            startActivity(intent);
        });

        profil_dosen.setOnClickListener(view -> {
            Intent intent = new Intent(progres_dosen.this, profil_dosen.class);
            intent.putExtra("NIP", nip); // Kirim NIP ke profil_dosen
            startActivity(intent);
        });

        jadwal_dosen.setOnClickListener(view -> {
            Intent intent = new Intent(progres_dosen.this, jadwal_dosen.class);
            intent.putExtra("NIP", nip); // Kirim NIP ke jadwal_dosen
            startActivity(intent);
        });

        // Referensi ke Firebase untuk data progres
        databaseReferenceProgres = FirebaseDatabase.getInstance().getReference("/progres");

        // Ambil data dari Firebase
        fetchDataProgres();
    }

    private void fetchDataProgres() {
        databaseReferenceProgres.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                progresLayout.removeAllViews(); // Hapus tampilan lama

                for (DataSnapshot proyekSnapshot : snapshot.getChildren()) {
                    for (DataSnapshot progresSnapshot : proyekSnapshot.getChildren()) {
                        String nipDosen = progresSnapshot.child("nipDosen").getValue(String.class);

                        if (nipDosen != null && nipDosen.equals(nip)) {
                            String namaKelompok = progresSnapshot.child("namaKelompok").getValue(String.class);
                            String linkProgres = progresSnapshot.child("linkProgres").getValue(String.class);
                            String tanggalUpload = progresSnapshot.child("tanggalUpload").getValue(String.class);

                            addItemToLayout(namaKelompok, linkProgres, tanggalUpload);
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(progres_dosen.this, "Gagal memuat data progres: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addItemToLayout(String namaKelompok, String linkProgres, String tanggalUpload) {
        // Inflate layout item_progres_dosen
        View itemView = LayoutInflater.from(this).inflate(R.layout.item_progres_dosen, progresLayout, false);

        TextView namaKelompokView = itemView.findViewById(R.id.nama_progres);
        TextView linkProgresView = itemView.findViewById(R.id.link_progres);
        TextView tanggalUploadView = itemView.findViewById(R.id.tanggal);

        namaKelompokView.setText(namaKelompok != null ? namaKelompok : "Tidak ada data");
        tanggalUploadView.setText(tanggalUpload != null ? tanggalUpload : "Tidak ada data");

        if (linkProgres != null && !linkProgres.isEmpty()) {
            linkProgresView.setText(linkProgres);
            linkProgresView.setTextColor(getResources().getColor(android.R.color.holo_blue_dark)); // Warna untuk hyperlink
            linkProgresView.setOnClickListener(v -> {
                // Buka link di browser
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(linkProgres));
                startActivity(intent);
            });
        } else {
            linkProgresView.setText("Tidak ada data");
        }

        // Tambahkan item ke layout
        progresLayout.addView(itemView);
    }
}
