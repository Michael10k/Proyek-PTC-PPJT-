package com.example.ith;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeActivity extends AppCompatActivity {

    private DatabaseReference mDatabase; // Referensi Firebase Database
    private GridLayout gridLayout;
    private ImageView proyekIcon, profilIcon,progresIcon, jadwal_icon; // Referensi untuk proyekIcon dan profilIcon
    private String nimLogin; // Variabel untuk menyimpan NIM pengguna yang login

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Ambil NIM dari SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        nimLogin = sharedPreferences.getString("nip", null); // "nip" menyimpan NIM/NIP pengguna yang login

        if (nimLogin != null) {
            Toast.makeText(this, "Selamat datang, " + nimLogin, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Tidak dapat memuat data pengguna.", Toast.LENGTH_SHORT).show();
        }

        // Inisialisasi Firebase Database
        mDatabase = FirebaseDatabase.getInstance().getReference("/users/dosen");

        // Inisialisasi GridLayout
        gridLayout = findViewById(R.id.gridLayoutDosen);

        // Inisialisasi ImageView untuk proyekIcon dan profilIcon
        proyekIcon = findViewById(R.id.proyek_icon);
        profilIcon = findViewById(R.id.profil_icon);
        progresIcon = findViewById(R.id.progres_icon);
        jadwal_icon = findViewById(R.id.jadwal_icon);

        // Menambahkan listener klik pada proyekIcon


        jadwal_icon.setOnClickListener(view -> {
            // Berpindah ke ProyekActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(HomeActivity.this, jadwal_mahasiswa.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        proyekIcon.setOnClickListener(view -> {
            // Berpindah ke ProyekActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(HomeActivity.this, proyek.class);
            intent.putExtra("nimLogin", nimLogin); // Kirim NIM login melalui Intent
            startActivity(intent);
        });

        // Menambahkan listener klik pada profilIcon
        profilIcon.setOnClickListener(view -> {
            // Berpindah ke ProfilActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(HomeActivity.this, profil.class);
            intent.putExtra("nimLogin", nimLogin); // Kirim NIM login melalui Intent
            startActivity(intent);
        });
        progresIcon.setOnClickListener(view -> {
            // Berpindah ke ProgresActivity
            Intent intent = new Intent(HomeActivity.this, progres.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        // Memuat data dosen dari Firebasebb
        loadDosenFromFirebase();
    }

    // Fungsi untuk memuat data dosen dari Firebase
    private void loadDosenFromFirebase() {
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                gridLayout.removeAllViews(); // Bersihkan GridLayout sebelum memperbarui data

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String namaDosen = snapshot.child("nick").getValue(String.class);
                    String photoUrl = snapshot.child("poto").getValue(String.class);
                    String nip = snapshot.getKey(); // NIP dosen dari key data

                    if (namaDosen != null && nip != null) {
                        addDosenToGrid(namaDosen, nip, photoUrl);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(HomeActivity.this, "Gagal memuat data dosen.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Fungsi untuk menambahkan dosen ke GridLayout
    private void addDosenToGrid(String namaDosen, String nip, String photoUrl) {
        // Inflate layout item dosen
        LinearLayout newDosenLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.list_item, null);

        // Tetapkan nama dosen pada TextView
        TextView textView = newDosenLayout.findViewById(R.id.nama1);
        textView.setText(namaDosen);

        // Tetapkan foto dosen pada ImageView
        ImageView imageView = newDosenLayout.findViewById(R.id.profil1);

        if (photoUrl != null && !photoUrl.isEmpty()) {
            Glide.with(this).load(photoUrl).placeholder(R.drawable.shape_cari).into(imageView);
        } else {
            imageView.setImageResource(R.drawable.shape_cari);
        }

        // Atur listener klik untuk layout dosen
        newDosenLayout.setOnClickListener(view -> {
            // Berpindah ke `status_dosen_mahasiswa` dengan mengirimkan NIP dosen dan NIM pengguna login
            Intent intent = new Intent(HomeActivity.this, status_dosen_mahasiswa.class);
            intent.putExtra("keyDosen", nip); // Kirim NIP dosen melalui Intent
            intent.putExtra("nimLogin", nimLogin); // Kirim NIM pengguna login melalui Intent
            startActivity(intent);
        });

        // Tambahkan layout ke GridLayout
        gridLayout.addView(newDosenLayout);
    }
}
