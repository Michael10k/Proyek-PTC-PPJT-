package com.example.ith;

import android.content.Intent;
import android.content.SharedPreferences;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class jadwal_dosen extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private String nip;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jadwal_dosen);

        ImageView profil_dosen = findViewById(R.id.profil_icon);
        ImageView progres_dosen = findViewById(R.id.progres_icon);
        ImageView home_dosen = findViewById(R.id.home_icon);

        home_dosen.setOnClickListener(view -> {
            String nipFromPrefs = sharedPreferences.getString("NIP", null); // Ambil NIP dari SharedPreferences
            if (nipFromPrefs != null) {
                Intent intent = new Intent(jadwal_dosen.this, home_dosen.class);
                intent.putExtra("NIP", nipFromPrefs);
                startActivity(intent);
            }
        });

        // Mengatur tombol profil dosen
        profil_dosen.setOnClickListener(view -> {
            String nipFromPrefs = sharedPreferences.getString("NIP", null); // Ambil NIP dari SharedPreferences
            if (nipFromPrefs != null) {
                Intent intent = new Intent(jadwal_dosen.this, profil_dosen.class);
                intent.putExtra("NIP", nipFromPrefs); // Kirimkan NIP ke profil_dosen
                startActivity(intent);
            }
        });

        progres_dosen.setOnClickListener(view -> {
            String nipFromPrefs = sharedPreferences.getString("NIP", null); // Ambil NIP dari SharedPreferences
            if (nipFromPrefs != null) {
                Intent intent = new Intent(jadwal_dosen.this, progres_dosen.class);
                intent.putExtra("NIP", nipFromPrefs); // Kirimkan NIP ke progres_dosen
                startActivity(intent);
            }
        });

        // Mengambil NIP dari Intent
        sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);

        // Ambil NIP dari Intent
        nip = getIntent().getStringExtra("NIP");
        if (nip == null || nip.isEmpty()) {
            Toast.makeText(this, "NIP tidak ditemukan!", Toast.LENGTH_SHORT).show();
            finish(); // Tutup Activity jika NIP tidak ditemukan
            return;
        }

        // Menampilkan nip untuk memastikan nilainya
        Log.d("jadwal_dosen", "NIP diterima: " + nip);

        // Mengatur referensi ke Firebase untuk "jadwal"
        databaseReference = FirebaseDatabase.getInstance().getReference("jadwal");

        // Memanggil fungsi untuk mengambil jadwal berdasarkan NIP
        fetchJadwalForDosen();
    }

    private void fetchJadwalForDosen() {
        // Mengambil data jadwal berdasarkan idDosen yang cocok dengan nip
        databaseReference.orderByChild("idDosen").equalTo(nip)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        List<Jadwal> jadwalPrioritas = new ArrayList<>();
                        List<Jadwal> jadwalNonPrioritas = new ArrayList<>();

                        // Memproses data jadwal yang diterima dari Firebase
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            Jadwal jadwal = snapshot.getValue(Jadwal.class);
                            if (jadwal != null) {
                                // Memisahkan jadwal berdasarkan status prioritas
                                if ("Prioritas".equals(jadwal.getPrioritas())) {
                                    jadwalPrioritas.add(jadwal); // Masukkan ke jadwalPrioritas
                                } else {
                                    jadwalNonPrioritas.add(jadwal); // Masukkan ke jadwalNonPrioritas
                                }
                            }
                        }

                        // Menampilkan jadwal prioritas ke layout_prioritas
                        LinearLayout layoutPrioritas = findViewById(R.id.layout_prioritas);
                        displayJadwal(layoutPrioritas, jadwalPrioritas);

                        // Menampilkan jadwal non-prioritas ke layout_non_prioritas
                        LinearLayout layoutNonPrioritas = findViewById(R.id.layout_non_prioritas);
                        displayJadwal(layoutNonPrioritas, jadwalNonPrioritas);

                        // Menampilkan pesan jika tidak ada jadwal ditemukan
                        if (jadwalPrioritas.isEmpty() && jadwalNonPrioritas.isEmpty()) {
                            Toast.makeText(jadwal_dosen.this, "Tidak ada jadwal ditemukan untuk NIP ini", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(jadwal_dosen.this, "Gagal memuat data jadwal: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void displayJadwal(LinearLayout layout, List<Jadwal> jadwalList) {
        layout.removeAllViews(); // Bersihkan layout sebelum menambahkan data baru

        for (Jadwal jadwal : jadwalList) {
            // Menggunakan layout item yang sudah ada untuk menampilkan data
            View itemView = getLayoutInflater().inflate(R.layout.item_jadwal_prioritas_dosen, layout, false);

            // Menampilkan Nama Kelompok, Tipe Pertemuan, dan Deskripsi
            TextView namaKlpTextView = itemView.findViewById(R.id.nama_klp);
            TextView tipeTextView = itemView.findViewById(R.id.tipe_pertemuan);
            TextView deskripsiTextView = itemView.findViewById(R.id.deskrisi);

            // Mengisi data yang sesuai ke TextView
            namaKlpTextView.setText("Nama Klp: " + jadwal.getNamaKlp());
            tipeTextView.setText("Tipe: " + jadwal.getTipePertemuan());
            deskripsiTextView.setText("Deskripsi: " + jadwal.getDeskripsi());

            // Menambahkan item ke layout
            layout.addView(itemView);
        }
    }

    // Kelas Jadwal untuk mendefinisikan struktur data
    public static class Jadwal {
        private String namaKlp;
        private String tipePertemuan;
        private String deskripsi;
        private String idDosen;
        private String prioritas;

        // Constructor default untuk Firebase
        public Jadwal() {}

        // Getter dan Setter
        public String getNamaKlp() {
            return namaKlp;
        }

        public void setNamaKlp(String namaKlp) {
            this.namaKlp = namaKlp;
        }

        public String getTipePertemuan() {
            return tipePertemuan;
        }

        public void setTipePertemuan(String tipePertemuan) {
            this.tipePertemuan = tipePertemuan;
        }

        public String getDeskripsi() {
            return deskripsi;
        }

        public void setDeskripsi(String deskripsi) {
            this.deskripsi = deskripsi;
        }

        public String getIdDosen() {
            return idDosen;
        }

        public void setIdDosen(String idDosen) {
            this.idDosen = idDosen;
        }

        public String getPrioritas() {
            return prioritas;
        }

        public void setPrioritas(String prioritas) {
            this.prioritas = prioritas;
        }
    }
}
