package com.example.ith;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class status_dosen_mahasiswa extends AppCompatActivity {

    private DatabaseReference databaseReference; // Referensi Firebase yang dinamis
    private ImageView progresIcon;
    private String nimLogin;
    private ImageView proyekIcon, profilIcon,progres_Icon, jadwal_icon, home_icon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_dosen_mahasiswa);

        // Mengambil NIP dosen dari Intent
        String nipDosen = getIntent().getStringExtra("keyDosen");

        if (nipDosen == null || nipDosen.isEmpty()) {
            Log.e("IntentError", "NIP dosen tidak ditemukan dalam Intent");
            finish();
            return;
        }

        proyekIcon = findViewById(R.id.proyek_icon);
        profilIcon = findViewById(R.id.profil_icon);
        progres_Icon = findViewById(R.id.progres_icon);
        jadwal_icon = findViewById(R.id.jadwal_icon);
        home_icon = findViewById(R.id.home_icon);

        TextView ajukan_jadwal = findViewById(R.id.ajukan_jadwal);
        ajukan_jadwal.setOnClickListener(view -> {
            // Berpindah ke ProyekActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(status_dosen_mahasiswa.this, jadwal_mahasiswa.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        TextView progresBimbingan = findViewById(R.id.progresBimbingan);
        progresBimbingan.setOnClickListener(view -> {
            // Berpindah ke ProgresActivity
            Intent intent = new Intent(status_dosen_mahasiswa.this, progres.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        jadwal_icon.setOnClickListener(view -> {
            // Berpindah ke ProyekActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(status_dosen_mahasiswa.this, jadwal_mahasiswa.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        proyekIcon.setOnClickListener(view -> {
            // Berpindah ke ProyekActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(status_dosen_mahasiswa.this, proyek.class);
            intent.putExtra("nimLogin", nimLogin); // Kirim NIM login melalui Intent
            startActivity(intent);
        });

        // Menambahkan listener klik pada profilIcon
        profilIcon.setOnClickListener(view -> {
            // Berpindah ke ProfilActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(status_dosen_mahasiswa.this, profil.class);
            intent.putExtra("nimLogin", nimLogin); // Kirim NIM login melalui Intent
            startActivity(intent);
        });
        progres_Icon.setOnClickListener(view -> {
            // Berpindah ke ProgresActivity
            Intent intent = new Intent(status_dosen_mahasiswa.this, progres.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        home_icon.setOnClickListener(view -> {
            // Berpindah ke ProgresActivity
            Intent intent = new Intent(status_dosen_mahasiswa.this, HomeActivity.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });




        nimLogin = getIntent().getStringExtra("nimLogin");

        progresIcon = findViewById(R.id.progres_icon);

        progresIcon.setOnClickListener(view -> {
            // Berpindah ke ProyekActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(status_dosen_mahasiswa.this, progres.class);
            intent.putExtra("nimLogin", nimLogin); // Kirim NIM login melalui Intent
            startActivity(intent);
        });

        Log.d("NIPDosen", "NIP yang diterima: " + nipDosen);

        // Referensi Firebase
        databaseReference = FirebaseDatabase.getInstance().getReference("/users/dosen/" + nipDosen);

        // Inisialisasi tampilan UI
        TextView namaDosen = findViewById(R.id.namaDosen);
        TextView siapMengajar = findViewById(R.id.status1);
        TextView kampus = findViewById(R.id.status2);
        TextView bimbinganTextView = findViewById(R.id.status4);
        TextView berhalanganTextView = findViewById(R.id.status3);
        TextView deskripsiTextView = findViewById(R.id.deskripsi);
        ImageView dosenImageView = findViewById(R.id.profilicon_status);

        // Tombol kembali menggunakan ImageView
        ImageView back = findViewById(R.id.back);
        back.setOnClickListener(view -> finish());

        // Memuat data dari Firebase
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String nama = dataSnapshot.child("nama").getValue(String.class);
                String status = dataSnapshot.child("status").getValue(String.class);
                String lokasiKampus = dataSnapshot.child("lokasi").getValue(String.class);
                String bimbinganData = dataSnapshot.child("bimbingan").getValue(String.class);
                String behalangan = dataSnapshot.child("status2").getValue(String.class);

                String fotoUrl = dataSnapshot.child("poto").getValue(String.class);

                namaDosen.setText(nama != null ? nama : "Nama tidak tersedia");
                siapMengajar.setText(status != null ? status : "null");
                kampus.setText(lokasiKampus != null ? lokasiKampus : "nul");
                bimbinganTextView.setText(bimbinganData != null ? bimbinganData : "null");
                berhalanganTextView.setText(behalangan != null ? behalangan : "null");


                if (fotoUrl != null) {
                    Glide.with(status_dosen_mahasiswa.this).load(fotoUrl).into(dosenImageView);
                } else {
                    dosenImageView.setImageResource(R.drawable.example_pic); // Gambar default
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("FirebaseError", "Terjadi kesalahan saat memuat data: " + databaseError.getMessage());
            }
        });
        // Mendapatkan data deskripsi secara real-time
        databaseReference.child("deskripsi").orderByKey().limitToLast(1).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String deskripsi = null;
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    deskripsi = snapshot.child("deskripsi").getValue(String.class);
                }

                Log.d("FirebaseData", "Deskripsi terbaru: " + deskripsi);
                deskripsiTextView.setText(deskripsi != null ? deskripsi : "Deskripsi tidak tersedia");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("FirebaseError", "Terjadi kesalahan saat memuat data: " + databaseError.getMessage());
            }
        });
    }
}


