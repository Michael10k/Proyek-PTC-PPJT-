package com.example.ith;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class home_dosen extends AppCompatActivity {

    // Mendeklarasikan SharedPreferences
    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "LoginPrefs";
    private static final String KEY_NIP = "nip";

    // Referensi Firebase
    private DatabaseReference databaseReference;

    private TextView namaDosen, siapMegajar, kampus1, bimbinganTextView, deskripsiTextView, berhalanganTextView;
    private ImageView dosenImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_dosen);

        // Mengambil NIP dari SharedPreferences
        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        String nip = sharedPreferences.getString(KEY_NIP, null);

        if (nip == null) {
            // Jika NIP tidak ada, kembali ke halaman login
            startActivity(new Intent(home_dosen.this, ITHRegis.class));
            finish();
            return;
        }

        TextView ajukan_jadwal = findViewById(R.id.ajukan_jadwal);
        ajukan_jadwal.setOnClickListener(view -> {
            String nipFromPrefs = sharedPreferences.getString(KEY_NIP, null); // Ambil NIP dari SharedPreferences
            if (nipFromPrefs != null) {
                Intent intent = new Intent(home_dosen.this, jadwal_dosen.class);
                intent.putExtra("NIP", nipFromPrefs);
                startActivity(intent);
            }
        });

        // Menginisialisasi referensi Firebase sesuai dengan NIP dosen yang login
        databaseReference = FirebaseDatabase.getInstance().getReference("/users/dosen/" + nip);

        // Menginisialisasi tampilan UI
        TextView update_status = findViewById(R.id.update_status);
//        ImageView cek_jadwal_dosen = findViewById(R.id.jadwal_icon);
        ImageView profil_dosen = findViewById(R.id.profil_icon);
        ImageView progres_dosen = findViewById(R.id.progres_icon);
        ImageView jadwal_dosen = findViewById(R.id.jadwal_icon);
        namaDosen = findViewById(R.id.namaDosen);
        siapMegajar = findViewById(R.id.status1);
        kampus1 = findViewById(R.id.status2);
        bimbinganTextView = findViewById(R.id.status4);
        berhalanganTextView = findViewById(R.id.status3);
        deskripsiTextView = findViewById(R.id.deskripsi);
        dosenImageView = findViewById(R.id.profilicon_status);

        // Mengatur tombol update status
        update_status.setOnClickListener(view -> {
            String nipFromPrefs = sharedPreferences.getString(KEY_NIP, null); // Ambil NIP dari SharedPreferences
            if (nipFromPrefs != null) {
                Intent intent = new Intent(home_dosen.this, StatusActivity.class);
                intent.putExtra("NIP", nipFromPrefs); // Kirimkan NIP ke StatusActivity
                startActivity(intent);
            } else {
                Log.e("LoginError", "NIP tidak ditemukan");
            }
        });

        // Mengatur tombol cek jadwal dosen
        jadwal_dosen.setOnClickListener(view -> {
            String nipFromPrefs = sharedPreferences.getString(KEY_NIP, null); // Ambil NIP dari SharedPreferences
            if (nipFromPrefs != null) {
                Intent intent = new Intent(home_dosen.this, jadwal_dosen.class);
                intent.putExtra("NIP", nipFromPrefs);
                startActivity(intent);
            }
        });

        // Mengatur tombol profil dosen
        profil_dosen.setOnClickListener(view -> {
            String nipFromPrefs = sharedPreferences.getString(KEY_NIP, null); // Ambil NIP dari SharedPreferences
            if (nipFromPrefs != null) {
                Intent intent = new Intent(home_dosen.this, profil_dosen.class);
                intent.putExtra("NIP", nipFromPrefs); // Kirimkan NIP ke profil_dosen
                startActivity(intent);
            }
        });

        progres_dosen.setOnClickListener(view -> {
            String nipFromPrefs = sharedPreferences.getString(KEY_NIP, null); // Ambil NIP dari SharedPreferences
            if (nipFromPrefs != null) {
                Intent intent = new Intent(home_dosen.this, progres_dosen.class);
                intent.putExtra("NIP", nipFromPrefs); // Kirimkan NIP ke progres_dosen
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();

        loadData();
    }

    private void loadData() {
        // Mengambil data dari Firebase
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String nama = dataSnapshot.child("nama").getValue(String.class);
                String status = dataSnapshot.child("status").getValue(String.class);
                String kampus = dataSnapshot.child("lokasi").getValue(String.class);
                String bimbinganData = dataSnapshot.child("bimbingan").getValue(String.class);
                String behalangan = dataSnapshot.child("status2").getValue(String.class);

                String fotoUrl = dataSnapshot.child("poto").getValue(String.class);

                // Menampilkan data di TextView
                namaDosen.setText(nama != null ? nama : "null");
                siapMegajar.setText(status != null ? status : "null");
                kampus1.setText(kampus != null ? kampus : "null");
                bimbinganTextView.setText(bimbinganData != null ? bimbinganData : "null");
                berhalanganTextView.setText(behalangan != null ? behalangan : "null");

                if (fotoUrl != null) {
                    Glide.with(home_dosen.this)
                            .load(fotoUrl)
                            .into(dosenImageView);
                } else {
                    dosenImageView.setImageResource(R.drawable.example_pic); // Gambar default jika URL kosong
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("FirebaseError", "Terjadi kesalahan saat memuat data: " + databaseError.getMessage());
            }
        });

        // Mendapatkan data deskripsi secara real-time
        databaseReference.child("deskripsi").orderByKey().limitToLast(1).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String deskripsi = null;
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    deskripsi = snapshot.child("deskripsi").getValue(String.class);
                }

                Log.d("FirebaseData", "Deskripsi terbaru: " + deskripsi);
                deskripsiTextView.setText(deskripsi != null ? deskripsi : "Deskripsi tidak tersedia");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("FirebaseError", "Terjadi kesalahan saat memuat data: " + databaseError.getMessage());
            }
        });
    }
}
