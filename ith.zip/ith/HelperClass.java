package com.example.ith;

public class HelperClass {
    String nama, nim, email, pass, conf_pass, role;

    // Constructor dengan role default sebagai 'mahasiswa'
    public HelperClass(String nama, String nim, String email, String pass, String conf_pass) {
        this.nama = nama;
        this.nim = nim;
        this.email = email;
        this.pass = pass;
        this.conf_pass = conf_pass;
        this.role = "mahasiswa";
    }

    // Getter dan Setter untuk nama
    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    // Getter dan Setter untuk nim
    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    // Getter dan Setter untuk email
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Getter dan Setter untuk pass
    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    // Getter dan Setter untuk conf_pass
    public String getConf_pass() {
        return conf_pass;
    }

    public void setConf_pass(String conf_pass) {
        this.conf_pass = conf_pass;
    }

    // Getter dan Setter untuk role
    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
