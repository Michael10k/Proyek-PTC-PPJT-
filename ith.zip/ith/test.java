package com.example.ith;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class test extends AppCompatActivity {

    private TextView textViewMahasiswaData;
    private DatabaseReference mahasiswaRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

//        textViewMahasiswaData = findViewById(R.id.textViewMahasiswaData);

        // Referensi ke node mahasiswa di Firebase
        mahasiswaRef = FirebaseDatabase.getInstance().getReference("users").child("mahasiswa");

        // Ambil semua data mahasiswa
        mahasiswaRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                StringBuilder data = new StringBuilder();

                // Loop melalui semua data mahasiswa
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    String nama = dataSnapshot.child("nama").getValue(String.class);
                    String nim = dataSnapshot.child("nim").getValue(String.class);

                    // Tambahkan data ke StringBuilder
                    data.append("------------").append("\nNama: ").append(nama).append("\nNIM: ").append(nim).append("\n\n");
                }

                // Tampilkan data di TextView
                textViewMahasiswaData.setText(data.toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {


                Toast.makeText(test.this, "Gagal mengambil data", Toast.LENGTH_SHORT).show();
                Log.e("FirebaseError", error.getMessage());
            }
        });
    }
}
