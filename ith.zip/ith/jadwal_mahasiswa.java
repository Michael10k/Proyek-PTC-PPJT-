package com.example.ith;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class jadwal_mahasiswa extends AppCompatActivity {

    private LinearLayout jadwalLayout;
    private DatabaseReference databaseReference;
    private String nimLogin; // Menyimpan NIM
    private ImageView proyekIcon, profilIcon,progresIcon, home_icon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jadwal_mahasiswa);

        // Menerima NIM yang dikirimkan dari Intent
        nimLogin = getIntent().getStringExtra("nimLogin");

        // Jika NIM tidak ada, tampilkan pesan dan keluar dari activity
        if (nimLogin == null || nimLogin.isEmpty()) {
            Toast.makeText(this, "NIM tidak ditemukan", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        proyekIcon = findViewById(R.id.proyek_icon);
        profilIcon = findViewById(R.id.profil_icon);
        progresIcon = findViewById(R.id.progres_icon);
        home_icon = findViewById(R.id.home_icon);

        home_icon.setOnClickListener(view -> {
            // Berpindah ke ProyekActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(jadwal_mahasiswa.this, HomeActivity.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        proyekIcon.setOnClickListener(view -> {
            // Berpindah ke ProyekActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(jadwal_mahasiswa.this, proyek.class);
            intent.putExtra("nimLogin", nimLogin); // Kirim NIM login melalui Intent
            startActivity(intent);
        });

        // Menambahkan listener klik pada profilIcon
        profilIcon.setOnClickListener(view -> {
            // Berpindah ke ProfilActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(jadwal_mahasiswa.this, profil.class);
            intent.putExtra("nimLogin", nimLogin); // Kirim NIM login melalui Intent
            startActivity(intent);
        });
        progresIcon.setOnClickListener(view -> {
            // Berpindah ke ProgresActivity
            Intent intent = new Intent(jadwal_mahasiswa.this, progres.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        // Inisialisasi LinearLayout untuk menampilkan jadwal
        jadwalLayout = findViewById(R.id.jadwal_layout);

        // Mengakses Firebase Realtime Database
        databaseReference = FirebaseDatabase.getInstance().getReference("jadwal");

        // Menambahkan item ke dalam LinearLayout secara dinamis
        fetchDataFromDatabase();

        // Menginisialisasi tombol "Tambah"
        TextView tambahButton = findViewById(R.id.textView2);

        // Menambahkan listener untuk tombol "Tambah"
        tambahButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pindah ke activity ajukan jadwal dengan mengirimkan NIM
                Intent intent = new Intent(jadwal_mahasiswa.this, ajukanJadwal.class);
                intent.putExtra("nimLogin", nimLogin); // Mengirimkan NIM ke ajukanJadwal
                startActivity(intent);
            }
        });
    }

    // Method untuk mengambil data dari Firebase berdasarkan NIM
    private void fetchDataFromDatabase() {
        // Mengakses Firebase Realtime Database dengan query berdasarkan nimLogin
        databaseReference.orderByChild("nimLogin").equalTo(nimLogin).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // Mengambil data dari Firebase
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        String namaKlp = snapshot.child("namaKlp").getValue(String.class);
                        String deskripsi = snapshot.child("deskripsi").getValue(String.class);
                        String tipePertemuan = snapshot.child("tipePertemuan").getValue(String.class);

                        // Menambahkan item ke dalam LinearLayout
                        addItemToJadwalLayout(namaKlp, deskripsi, tipePertemuan);
                    }
                } else {
                    Toast.makeText(jadwal_mahasiswa.this, "Tidak ada jadwal ditemukan untuk NIM ini", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Menangani error jika data gagal diambil
                Toast.makeText(jadwal_mahasiswa.this, "Gagal memuat data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Method untuk menambahkan item ke dalam jadwal_layout
    private void addItemToJadwalLayout(String namaKlp, String deskripsi, String tipePertemuan) {
        // Menggunakan LayoutInflater untuk memuat XML item_jadwal
        LayoutInflater inflater = LayoutInflater.from(this);
        LinearLayout itemView = (LinearLayout) inflater.inflate(R.layout.item_jadwal, jadwalLayout, false);

        // Memodifikasi TextView di dalam itemView
        TextView namaKlpView = itemView.findViewById(R.id.nama_klp);
        namaKlpView.setText(namaKlp);

        TextView deskripsiView = itemView.findViewById(R.id.deskrisi);
        deskripsiView.setText(deskripsi);

        TextView tipePertemuanView = itemView.findViewById(R.id.tipe_pertemuan);
        tipePertemuanView.setText(tipePertemuan);

        // Menambahkan itemView ke dalam jadwalLayout
        jadwalLayout.addView(itemView);
    }
}
