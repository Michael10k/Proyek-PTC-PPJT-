package com.example.ith;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class progres extends AppCompatActivity {

    private LinearLayout proyekLayout;
    private DatabaseReference databaseReferenceProyek, databaseReferenceProgres;
    private String nimLogin;
    private ImageView proyekIcon, profilIcon, jadwal_icon, home_icon;
    private Set<String> displayedProyekIds = new HashSet<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progres);

        proyekIcon = findViewById(R.id.proyek_icon);
        profilIcon = findViewById(R.id.profil_icon);
        home_icon = findViewById(R.id.home_icon);
        jadwal_icon = findViewById(R.id.jadwal_icon);

        jadwal_icon.setOnClickListener(view -> {
            Intent intent = new Intent(progres.this, jadwal_mahasiswa.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        proyekIcon.setOnClickListener(view -> {
            Intent intent = new Intent(progres.this, proyek.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        profilIcon.setOnClickListener(view -> {
            Intent intent = new Intent(progres.this, profil.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        home_icon.setOnClickListener(view -> {
            Intent intent = new Intent(progres.this, HomeActivity.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        proyekLayout = findViewById(R.id.progres_layout);

        nimLogin = getIntent().getStringExtra("nimLogin");

        if (nimLogin == null || nimLogin.isEmpty()) {
            Toast.makeText(this, "NIM tidak ditemukan", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        databaseReferenceProyek = FirebaseDatabase.getInstance().getReference("/users/mahasiswa/" + nimLogin + "/proyek");
        databaseReferenceProgres = FirebaseDatabase.getInstance().getReference("/progres");

        fetchData();
    }

    private void fetchData() {
        databaseReferenceProyek.addValueEventListener(new com.google.firebase.database.ValueEventListener() {
            @Override
            public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot snapshot) {
                for (com.google.firebase.database.DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    String proyekId = dataSnapshot.getKey();
                    String namaProyek = dataSnapshot.child("namaProyek").getValue(String.class);

                    if (namaProyek != null && proyekId != null) {
                        if (!displayedProyekIds.contains(proyekId)) {
                            displayedProyekIds.add(proyekId);
                            fetchProgresForProject(proyekId, namaProyek);
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull com.google.firebase.database.DatabaseError error) {
                Toast.makeText(progres.this, "Gagal memuat data proyek.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void fetchProgresForProject(String proyekId, String namaProyek) {
        databaseReferenceProgres.child(proyekId).addValueEventListener(new com.google.firebase.database.ValueEventListener() {
            @Override
            public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot snapshot) {
                int totalProgres = 0;
                int targetProgres = 5;

                for (com.google.firebase.database.DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    totalProgres++;
                }

                int persentaseProgres = (int) ((totalProgres / (float) targetProgres) * 100);
                addItemToLayout(proyekId, namaProyek, persentaseProgres);
            }

            @Override
            public void onCancelled(@NonNull com.google.firebase.database.DatabaseError error) {
                Toast.makeText(progres.this, "Gagal memuat data progres.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addItemToLayout(String proyekId, String namaProyek, int persentaseProgres) {
        // Cek apakah proyekId sudah ada dalam layout
        View existingView = proyekLayout.findViewWithTag(proyekId);

        if (existingView != null) {
            // Jika tampilan sudah ada, cukup perbarui persentase
            TextView persentaseProgresView = existingView.findViewById(R.id.persen);
            persentaseProgresView.setText(" " + persentaseProgres + "%");
        } else {
            // Jika tampilan belum ada, buat tampilan baru
            View itemView = LayoutInflater.from(this).inflate(R.layout.item_progres, proyekLayout, false);
            TextView namaProyekView = itemView.findViewById(R.id.nama_progres);
            TextView persentaseProgresView = itemView.findViewById(R.id.persen);

            namaProyekView.setText(namaProyek);
            persentaseProgresView.setText(" " + persentaseProgres + "%");

            // Tandai tampilan dengan proyekId
            itemView.setTag(proyekId);

            itemView.setOnClickListener(v -> showUpdateDialog(proyekId, namaProyek, persentaseProgresView));

            proyekLayout.addView(itemView);
        }
    }

    private void showUpdateDialog(String proyekId, String namaProyek, TextView persentaseProgresView) {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.update_progres);
        dialog.setCancelable(true);

        EditText namaKelompokInput = dialog.findViewById(R.id.deskripsi_progres);
        EditText linkProgresInput = dialog.findViewById(R.id.link_progres);
        EditText nipDosenInput = dialog.findViewById(R.id.id_dosen);
        TextView saveButton = dialog.findViewById(R.id.upload_button);

        saveButton.setOnClickListener(view -> {
            String namaKelompok = namaKelompokInput.getText().toString().trim();
            String linkProgres = linkProgresInput.getText().toString().trim();
            String nipDosen = nipDosenInput.getText().toString().trim();

            if (namaKelompok.isEmpty() || linkProgres.isEmpty() || nipDosen.isEmpty()) {
                Toast.makeText(this, "Semua kolom harus diisi!", Toast.LENGTH_SHORT).show();
                return;
            }

            String tanggalUpload = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
            String idProgres = databaseReferenceProgres.push().getKey();
            Map<String, Object> progresData = new HashMap<>();
            progresData.put("namaKelompok", namaKelompok);
            progresData.put("linkProgres", linkProgres);
            progresData.put("tanggalUpload", tanggalUpload);
            progresData.put("nipDosen", nipDosen);

            if (idProgres != null) {
                databaseReferenceProgres.child(proyekId).child(idProgres).setValue(progresData).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(this, "Progres berhasil ditambahkan!", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                        updatePersentaseProgres(proyekId, persentaseProgresView);
                    } else {
                        Toast.makeText(this, "Gagal menambahkan progres.", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        dialog.show();
    }

    private void updatePersentaseProgres(String proyekId, TextView persentaseProgresView) {
        databaseReferenceProgres.child(proyekId).addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
            @Override
            public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot snapshot) {
                int totalProgres = 0;
                int targetProgres = 16;

                for (com.google.firebase.database.DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    totalProgres++;
                }

                int persentaseProgres = (int) ((totalProgres / (float) targetProgres) * 100);
                persentaseProgresView.setText(" " + persentaseProgres + "%");
            }

            @Override
            public void onCancelled(@NonNull com.google.firebase.database.DatabaseError error) {
                Toast.makeText(progres.this, "Gagal memperbarui data progres.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
