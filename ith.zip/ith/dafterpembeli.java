
package com.example.ith;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class dafterpembeli extends AppCompatActivity {

    private ListView listViewBarang;
    private Button buttonUpdate, buttonHapus;
    private DatabaseReference databaseBarang;
    private List<String> barangList; // Menyimpan nama barang
    private ArrayAdapter<String> barangAdapter; // ArrayAdapter untuk menampilkan data

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tugas5);

        // Inisialisasi tampilan
        listViewBarang = findViewById(R.id.listViewBarang);
        buttonUpdate = findViewById(R.id.buttonUpdate);
        buttonHapus = findViewById(R.id.buttonHapus);

        // Inisialisasi list untuk menampung nama barang
        barangList = new ArrayList<>();

        // Referensi ke Firebase Realtime Database
        databaseBarang = FirebaseDatabase.getInstance().getReference("Barang");

        // Menampilkan semua data barang dari Firebase
        tampilkanSemuaDataBarang();

        // Menambahkan listener untuk tombol update dan hapus
        buttonUpdate.setOnClickListener(v -> updatePembelian());
        buttonHapus.setOnClickListener(v -> hapusPembelian());
    }

    // Metode untuk mengambil dan menampilkan semua data barang dari Firebase
    private void tampilkanSemuaDataBarang() {
        databaseBarang.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                barangList.clear(); // Mengosongkan daftar barang sebelum menambah data baru

                // Iterasi melalui semua data dalam node "Barang"
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String nama = snapshot.child("nama").getValue(String.class);

                    // Menambahkan nama barang ke dalam daftar
                    barangList.add(nama);
                }

                // Menetapkan adapter untuk ListView menggunakan ArrayAdapter
                barangAdapter = new ArrayAdapter<>(dafterpembeli.this, android.R.layout.simple_list_item_1, barangList);
                listViewBarang.setAdapter(barangAdapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(dafterpembeli.this, "Gagal mengambil data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Metode untuk memperbarui pembelian (belum diimplementasikan)
    private void updatePembelian() {
        // Anda dapat menambahkan logika untuk memperbarui data barang di sini
        Toast.makeText(this, "Fitur Update belum diimplementasikan", Toast.LENGTH_SHORT).show();
    }

    // Metode untuk menghapus pembelian (belum diimplementasikan)
    private void hapusPembelian() {
        // Anda dapat menambahkan logika untuk menghapus data barang di sini
        Toast.makeText(this, "Fitur Delete belum diimplementasikan", Toast.LENGTH_SHORT).show();
    }
}
