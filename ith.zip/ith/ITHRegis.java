package com.example.ith;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ITHRegis extends AppCompatActivity {
    private EditText loginNim, loginPass;
    private DatabaseReference userRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ithlogin);

        // Inisialisasi Firebase
        userRef = FirebaseDatabase.getInstance().getReference("users");

        // Inisialisasi tampilan
        loginNim = findViewById(R.id.loginNim);
        loginPass = findViewById(R.id.loginPass);
        Button masuk = findViewById(R.id.masuk);

        // Event listener untuk tombol masuk
        masuk.setOnClickListener(view -> {
            String nim = loginNim.getText().toString().trim();
            String pass = loginPass.getText().toString().trim();

            if (TextUtils.isEmpty(nim)) {
                Toast.makeText(ITHRegis.this, "Masukkan NIM/NIP", Toast.LENGTH_SHORT).show();
            } else if (TextUtils.isEmpty(pass)) {
                Toast.makeText(ITHRegis.this, "Masukkan Kata Sandi", Toast.LENGTH_SHORT).show();
            } else {
                loginUser(nim, pass);
            }
        });
    }

    private void loginUser(String nim, String pass) {
        // Cek apakah pengguna adalah admin
        userRef.child("admin").child(nim).get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult().exists()) {
                String correctPass = task.getResult().child("pass_admin").getValue(String.class);
                if (pass.equals(correctPass)) {
                    saveNimToPreferences(nim);
                    Intent intent = new Intent(ITHRegis.this, HomeAdminActivity.class); // Ganti dengan activity untuk admin
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "Password salah untuk Admin", Toast.LENGTH_SHORT).show();
                }
            } else {
                // Jika bukan admin, cek sebagai dosen
                userRef.child("dosen").child(nim).get().addOnCompleteListener(task2 -> {
                    if (task2.isSuccessful() && task2.getResult().exists()) {
                        String correctPass = task2.getResult().child("pass_dosen").getValue(String.class);
                        if (pass.equals(correctPass)) {
                            saveNimToPreferences(nim);
                            Intent intent = new Intent(ITHRegis.this, home_dosen.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(this, "Password salah untuk Dosen", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        // Jika bukan dosen, cek sebagai mahasiswa
                        userRef.child("mahasiswa").child(nim).get().addOnCompleteListener(task3 -> {
                            if (task3.isSuccessful() && task3.getResult().exists()) {
                                String correctPass = task3.getResult().child("pass").getValue(String.class);
                                if (pass.equals(correctPass)) {
                                    saveNimToPreferences(nim); // Simpan NIM mahasiswa
                                    Intent intent = new Intent(ITHRegis.this, HomeActivity.class);
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(this, "Password salah untuk Mahasiswa", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(this, "NIM/NIP tidak ditemukan", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
            }
        });
    }

    // Fungsi untuk menyimpan NIM/NIP ke SharedPreferences
    private void saveNimToPreferences(String nim) {
        SharedPreferences sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("nip", nim); // Menggunakan "nip" sebagai kunci umum untuk NIM/NIP
        editor.apply();
    }
}
