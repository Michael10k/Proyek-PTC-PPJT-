package com.example.ith;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class UpdateUserActivity extends AppCompatActivity {

    private EditText editTextNama, editTextNIM, editTextEmail, editTextPass;
    private Button buttonUpdate;
    private String nim, nama, email, pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.updateadmin2);

        // Inisialisasi EditText dan Button
        editTextNama = findViewById(R.id.editTextNama);
        editTextNIM = findViewById(R.id.editTextNIM);
        editTextEmail = findViewById(R.id.editTextEmail);
        buttonUpdate = findViewById(R.id.buttonSimpan);

        // Ambil data yang diterima dari Intent
        nim = getIntent().getStringExtra("NIM");
        nama = getIntent().getStringExtra("NAMA");
        email = getIntent().getStringExtra("EMAIL");
        pass = getIntent().getStringExtra("PASS");

        // Set data pada EditText
        editTextNama.setText(nama);
        editTextNIM.setText(nim);
        editTextEmail.setText(email);
        editTextPass.setText(pass);

        // Tombol Update
        buttonUpdate.setOnClickListener(v -> {
            // Ambil nilai yang diubah
            String updatedNama = editTextNama.getText().toString();
            String updatedEmail = editTextEmail.getText().toString();
            String updatedPass = editTextPass.getText().toString();

            // Validasi input (optional)
            if (updatedNama.isEmpty() || updatedEmail.isEmpty() || updatedPass.isEmpty()) {
                Toast.makeText(UpdateUserActivity.this, "Semua field harus diisi", Toast.LENGTH_SHORT).show();
                return;
            }

            // Update data di Firebase
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("/users");

            // Gunakan nim atau ID pengguna untuk memperbarui data
            databaseReference.child(nim).child("nama").setValue(updatedNama);
            databaseReference.child(nim).child("email").setValue(updatedEmail);
            databaseReference.child(nim).child("pass").setValue(updatedPass);

            // Menampilkan pesan keberhasilan
            Toast.makeText(UpdateUserActivity.this, "Data berhasil diupdate", Toast.LENGTH_SHORT).show();
            finish();  // Menutup Activity setelah update berhasil
        });
    }
}
