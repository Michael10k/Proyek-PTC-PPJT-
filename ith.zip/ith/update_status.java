//package com.example.ith;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.ImageView;
//
//import androidx.activity.EdgeToEdge;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.core.graphics.Insets;
//import androidx.core.view.ViewCompat;
//import androidx.core.view.WindowInsetsCompat;
//
//public class update_status extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        EdgeToEdge.enable(this);
//        setContentView(R.layout.activity_update_status);
//
//        ImageView back = findViewById(R.id.back);
//        back.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(update_status.this, home_dosen.class));
//            }
//        });
//
//        ImageView profil_dosen = findViewById(R.id.profil_icon);
//        profil_dosen.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(update_status.this, profil_dosen.class));
//            }
//        });
//
//        ImageView home_dosen = findViewById(R.id.home_icon);
//        home_dosen.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(update_status.this, home_dosen.class));
//            }
//        });
//
//        ImageView cek_jadwal_dosen = findViewById(R.id.jadwal_icon);
//        cek_jadwal_dosen.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(update_status.this, jadwal_dosen.class));
//            }
//        });
//
//    }
//}