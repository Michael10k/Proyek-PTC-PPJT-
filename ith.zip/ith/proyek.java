package com.example.ith;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class proyek extends AppCompatActivity {

    private DatabaseReference databaseProyek;
    private TextView tambahButton;
    private LinearLayout containerProyek;
    private String nimLogin; // Variabel untuk menyimpan NIM pengguna yang login
    private ImageView progresIcon, profilIcon, jadwal_icon, home_icon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proyek);

        // Ambil NIM pengguna login dari Intent
        nimLogin = getIntent().getStringExtra("nimLogin");

        if (nimLogin == null) {
            Toast.makeText(this, "Gagal mendapatkan NIM pengguna.", Toast.LENGTH_SHORT).show();
            finish(); // Tutup activity jika NIM tidak ditemukan
            return;
        }

        progresIcon = findViewById(R.id.progres_icon);
        profilIcon = findViewById(R.id.profil_icon);
        home_icon = findViewById(R.id.home_icon);
        jadwal_icon = findViewById(R.id.jadwal_icon);

        // Menambahkan listener klik pada proyekIcon


        jadwal_icon.setOnClickListener(view -> {
            // Berpindah ke ProyekActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(proyek.this, jadwal_mahasiswa.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        progresIcon.setOnClickListener(view -> {
            // Berpindah ke ProyekActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(proyek.this, progres.class);
            intent.putExtra("nimLogin", nimLogin); // Kirim NIM login melalui Intent
            startActivity(intent);
        });

        // Menambahkan listener klik pada profilIcon
        profilIcon.setOnClickListener(view -> {
            // Berpindah ke ProfilActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(proyek.this, profil.class);
            intent.putExtra("nimLogin", nimLogin); // Kirim NIM login melalui Intent
            startActivity(intent);
        });
        home_icon.setOnClickListener(view -> {
            // Berpindah ke ProgresActivity
            Intent intent = new Intent(proyek.this, HomeActivity.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        // Inisialisasi Firebase Database dengan NIM pengguna
        databaseProyek = FirebaseDatabase.getInstance().getReference("/users/mahasiswa/" + nimLogin + "/proyek");

        // Inisialisasi tombol 'Tambah'
        tambahButton = findViewById(R.id.textView2);

        // Inisialisasi LinearLayout container untuk proyek
        containerProyek = findViewById(R.id.proyek_layout);

        // Menampilkan data proyek yang ada di Firebase
        fetchProyekFromFirebase();

        // Menambahkan listener klik untuk tombol 'Tambah'
        tambahButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Menampilkan dialog untuk menambah proyek
                showTambahProyekDialog();
            }
        });
    }

    // Fungsi untuk menampilkan dialog tambah proyek
    private void showTambahProyekDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.update_proyek, null);

        EditText namaProyekEditText = dialogView.findViewById(R.id.nama_proyek);
        EditText deskripsiProyekEditText = dialogView.findViewById(R.id.deskripsi_proyek);

        AlertDialog.Builder builder = new AlertDialog.Builder(proyek.this);
        builder.setTitle("Tambah Proyek")
                .setView(dialogView)
                .setPositiveButton("Tambah", (dialog, which) -> {
                    String namaProyek = namaProyekEditText.getText().toString();
                    String deskripsiProyek = deskripsiProyekEditText.getText().toString();

                    // Mengizinkan input kosong untuk nama proyek dan deskripsi
                    saveProyekToFirebase(namaProyek, deskripsiProyek);

                    // Menampilkan pesan
                    String message = (namaProyek.isEmpty() && deskripsiProyek.isEmpty()) ?
                            "Proyek ditambahkan, meskipun kosong." :
                            "Proyek ditambahkan: " + namaProyek;

                    Toast.makeText(proyek.this, message, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Batal", null)
                .create()
                .show();
    }

    // Fungsi untuk menyimpan proyek ke Firebase
    private void saveProyekToFirebase(String namaProyek, String deskripsiProyek) {
        String proyekId = databaseProyek.push().getKey();
        Proyek proyek = new Proyek(namaProyek, deskripsiProyek);

        if (proyekId != null) {
            // Menyimpan proyek, bahkan jika nama atau deskripsi kosong
            databaseProyek.child(proyekId).setValue(proyek);
        }
    }

    // Fungsi untuk menampilkan data proyek dari Firebase
    private void fetchProyekFromFirebase() {
        databaseProyek.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                containerProyek.removeAllViews(); // Menghapus tampilan proyek lama

                if (!snapshot.exists()) {
                    // Jika belum ada proyek
                    Toast.makeText(proyek.this, "Belum ada proyek. Silakan tambahkan proyek pertama Anda!", Toast.LENGTH_SHORT).show();
                    // Tampilkan dialog jika belum ada proyek
                    showAddProjectDialog();
                } else {
                    // Jika ada proyek
                    for (DataSnapshot proyekSnapshot : snapshot.getChildren()) {
                        Proyek proyek = proyekSnapshot.getValue(Proyek.class);
                        if (proyek != null) {
                            addProyekToLayout(proyek.getNamaProyek(), proyek.getDeskripsiProyek());
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("Firebase", "Gagal mengambil data proyek: " + error.getMessage());
            }
        });
    }

    // Fungsi untuk menambahkan proyek ke dalam layout utama
    private void addProyekToLayout(String namaProyek, String deskripsiProyek) {
        View proyekItemView = LayoutInflater.from(proyek.this).inflate(R.layout.item_proyek, containerProyek, false);

        TextView namaProyekTextView = proyekItemView.findViewById(R.id.proyek1);
        TextView deskripsiProyekTextView = proyekItemView.findViewById(R.id.deskripsi);

        // Menampilkan nama dan deskripsi proyek
        namaProyekTextView.setText(namaProyek);
        deskripsiProyekTextView.setText(deskripsiProyek);

        // Menambahkan item proyek ke dalam layout
        containerProyek.addView(proyekItemView);
    }

    // Fungsi untuk menampilkan dialog jika belum ada proyek
    private void showAddProjectDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(proyek.this);
        builder.setTitle("Belum ada Proyek")
                .setMessage("Anda belum memiliki proyek. Tambahkan proyek pertama Anda sekarang.")
                .setPositiveButton("Tambah Proyek", (dialog, which) -> showTambahProyekDialog())
                .setNegativeButton("Tutup", (dialog, which) -> finish())
                .create()
                .show();
    }

    // Kelas Proyek untuk menyimpan data proyek
    public static class Proyek {
        private String namaProyek;
        private String deskripsiProyek;

        public Proyek() {
            // Diperlukan oleh Firebase
        }

        public Proyek(String namaProyek, String deskripsiProyek) {
            this.namaProyek = namaProyek;
            this.deskripsiProyek = deskripsiProyek;
        }

        public String getNamaProyek() {
            return namaProyek;
        }

        public String getDeskripsiProyek() {
            return deskripsiProyek;
        }
    }
}
