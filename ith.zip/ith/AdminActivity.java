//package com.example.ith;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.Button;
//import android.widget.LinearLayout;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.ValueEventListener;
//
//public class AdminActivity extends AppCompatActivity {
//
//    private LinearLayout userContainer;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.adminactivity);
//
//        // Inisialisasi userContainer dari layout
//        userContainer = findViewById(R.id.userContainer);
//
//        // Ambil reference ke Firebase Realtime Database
//        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("/users");
//
//        // Menambahkan listener untuk mengambil data dari Firebase
//        databaseReference.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                userContainer.removeAllViews();  // Bersihkan tampilan sebelumnya
//
//                // Looping untuk setiap pengguna yang ada di dalam "Users"
//                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
//                    // Ambil data setiap field untuk user
//                    String nim = userSnapshot.child("nim").getValue(String.class);
//                    String nama = userSnapshot.child("nama").getValue(String.class);
//                    String email = userSnapshot.child("email").getValue(String.class);
//                    String pass = userSnapshot.child("pass").getValue(String.class);
//                    String conf_pass = userSnapshot.child("conf_pass").getValue(String.class);
//
//                    // Buat layout untuk setiap data user
//                    LinearLayout userLayout = new LinearLayout(AdminActivity.this);
//                    userLayout.setOrientation(LinearLayout.VERTICAL);
//                    userLayout.setPadding(8, 8, 8, 8);
//
//                    // Nama
//                    TextView namaTextView = new TextView(AdminActivity.this);
//                    namaTextView.setText("Nama: " + nama);
//                    userLayout.addView(namaTextView);
//
//                    // NIM
//                    TextView nimTextView = new TextView(AdminActivity.this);
//                    nimTextView.setText("NIM: " + nim);
//                    userLayout.addView(nimTextView);
//
//                    // Email
//                    TextView emailTextView = new TextView(AdminActivity.this);
//                    emailTextView.setText("Email: " + email);
//                    userLayout.addView(emailTextView);
//
//                    // Password
//                    TextView passTextView = new TextView(AdminActivity.this);
//                    passTextView.setText("Password: " + pass);
//                    userLayout.addView(passTextView);
//
//                    // Confirm Password
//                    TextView confPassTextView = new TextView(AdminActivity.this);
//                    confPassTextView.setText("Confirm Password: " + conf_pass);
//                    userLayout.addView(confPassTextView);
//
//                    // Tombol Update
//                    Button updateButton = new Button(AdminActivity.this);
//                    updateButton.setText("Update");
//                    updateButton.setOnClickListener(v -> {
//                        // Aksi Update, berdasarkan NIM
//                        Intent intent = new Intent(AdminActivity.this, UpdateUserActivity.class);
//                        intent.putExtra("NIM", nim);
//                        intent.putExtra("NAMA", nama);
//                        intent.putExtra("EMAIL", email);
//                        intent.putExtra("PASS", pass);
//                        startActivity(intent);
//                    });
//                    userLayout.addView(updateButton);
//
//                    // Tombol Delete
//                    Button deleteButton = new Button(AdminActivity.this);
//                    deleteButton.setText("Delete");
//                    deleteButton.setOnClickListener(v -> {
//                        // Hapus pengguna dari Firebase berdasarkan NIM
//                        if (nim != null) {
//                            databaseReference.orderByChild("nim").equalTo(nim).addListenerForSingleValueEvent(new ValueEventListener() {
//                                @Override
//                                public void onDataChange(@NonNull DataSnapshot snapshot) {
//                                    if (snapshot.exists()) {
//                                        for (DataSnapshot userSnapshot : snapshot.getChildren()) {
//                                            userSnapshot.getRef().removeValue().addOnCompleteListener(task -> {
//                                                if (task.isSuccessful()) {
//                                                    Toast.makeText(AdminActivity.this, "User " + nama + " berhasil dihapus", Toast.LENGTH_SHORT).show();
//                                                } else {
//                                                    Toast.makeText(AdminActivity.this, "Gagal menghapus user", Toast.LENGTH_SHORT).show();
//                                                }
//                                            });
//                                        }
//                                    } else {
//                                        Toast.makeText(AdminActivity.this, "User tidak ditemukan", Toast.LENGTH_SHORT).show();
//                                    }
//                                }
//
//                                @Override
//                                public void onCancelled(@NonNull DatabaseError error) {
//                                    Toast.makeText(AdminActivity.this, "Gagal mengakses data", Toast.LENGTH_SHORT).show();
//                                }
//                            });
//                        }
//                    });
//                    userLayout.addView(deleteButton);
//
//                    // Tambahkan userLayout ke container utama
//                    userContainer.addView(userLayout);
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//                // Tampilkan pesan error jika gagal mengambil data
//                Toast.makeText(AdminActivity.this, "Gagal mengambil data", Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//}
