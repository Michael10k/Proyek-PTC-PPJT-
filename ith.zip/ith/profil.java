package com.example.ith;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class profil extends AppCompatActivity {

    private TextView textViewNama;
    private EditText editTextNick, editTextNim, editTextEmail, editTextProdi;
    private TextView buttonEditProfile;
    private ImageView progresIcon, proyekIcon, jadwalIcon, homeIcon;
    private String nimLogin; // NIM mahasiswa yang dikirim dari HomeActivity
    private DatabaseReference databaseReference;
    private boolean isEditMode = false; // Mode untuk mengatur apakah sedang dalam mode edit

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);

        // Logout Button
        TextView logoutButton = findViewById(R.id.logoutButton);
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearSessionData(); // Hapus data sesi

                // Pindahkan pengguna kembali ke halaman login
                Intent intent = new Intent(profil.this, ITHRegis.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Menghapus semua aktivitas sebelumnya
                startActivity(intent);
                finish(); // Menutup aktivitas ini
            }
        });

        // Inisialisasi ikon
        proyekIcon = findViewById(R.id.proyek_icon);
        progresIcon = findViewById(R.id.progres_icon);
        homeIcon = findViewById(R.id.home_icon);
        jadwalIcon = findViewById(R.id.jadwal_icon);

        // Klik event untuk jadwalIcon
        jadwalIcon.setOnClickListener(view -> {
            // Berpindah ke JadwalActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(profil.this, jadwal_mahasiswa.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        // Klik event untuk proyekIcon
        proyekIcon.setOnClickListener(view -> {
            // Berpindah ke ProyekActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(profil.this, proyek.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        // Klik event untuk progresIcon
        progresIcon.setOnClickListener(view -> {
            // Berpindah ke ProfilActivity dan mengirimkan NIM pengguna login
            Intent intent = new Intent(profil.this, profil.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        // Klik event untuk homeIcon
        homeIcon.setOnClickListener(view -> {
            // Berpindah ke HomeActivity
            Intent intent = new Intent(profil.this, HomeActivity.class);
            intent.putExtra("nimLogin", nimLogin);
            startActivity(intent);
        });

        // Ambil NIM dari Intent
        nimLogin = getIntent().getStringExtra("nimLogin");
        if (nimLogin == null || nimLogin.isEmpty()) {
            Toast.makeText(this, "NIM tidak ditemukan!", Toast.LENGTH_SHORT).show();
            finish(); // Tutup Activity jika NIM tidak ditemukan
            return;
        }

        // Inisialisasi elemen UI
        textViewNama = findViewById(R.id.nama_profil);
        editTextNick = findViewById(R.id.user_name);
        editTextNim = findViewById(R.id.user_nim);
        editTextEmail = findViewById(R.id.user_email);
        editTextProdi = findViewById(R.id.user_prodi);
        buttonEditProfile = findViewById(R.id.button_editP);

        // Atur EditText agar tidak dapat diedit saat pertama kali
        toggleEditMode(false);

        // Ambil data dari Firebase berdasarkan NIM
        loadDataFromFirebase();

        // Logika untuk tombol Edit Profil
        buttonEditProfile.setOnClickListener(v -> {
            if (isEditMode) {
                // Simpan data ke Firebase jika sedang dalam mode edit
                saveDataToFirebase();
            } else {
                // Aktifkan mode edit
                toggleEditMode(true);
            }
        });

        // Logika klik untuk kembali ke Home
        homeIcon.setOnClickListener(v -> {
            // Navigasi ke Home Activity
            Intent intent = new Intent(profil.this, HomeActivity.class);
            startActivity(intent);
            finish(); // Tutup activity ini setelah pindah
        });
    }

    // Fungsi untuk mengambil data dari Firebase
    private void loadDataFromFirebase() {
        databaseReference = FirebaseDatabase.getInstance().getReference("users/mahasiswa").child(nimLogin);

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Ambil data dari Firebase
                    String nama = snapshot.child("nama").getValue(String.class);
                    String nick = snapshot.child("nick").getValue(String.class);
                    String email = snapshot.child("poto").getValue(String.class);
                    String prodi = snapshot.child("prodi").getValue(String.class);

                    // Tampilkan data di UI
                    textViewNama.setText(nama != null ? nama : "Nama tidak tersedia");
                    editTextNick.setText(nick != null ? nick : "");
                    editTextNim.setText(nimLogin); // Gunakan NIM login di sini
                    editTextEmail.setText(email != null ? email : "");
                    editTextProdi.setText(prodi != null ? prodi : "");
                } else {
                    Toast.makeText(profil.this, "Data untuk NIM ini tidak ditemukan", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(profil.this, "Gagal memuat data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Fungsi untuk menyimpan data ke Firebase
    private void saveDataToFirebase() {
        String updatedNick = editTextNick.getText().toString();
        String updatedEmail = editTextEmail.getText().toString();
        String updatedProdi = editTextProdi.getText().toString();

        if (!updatedNick.isEmpty() && !updatedEmail.isEmpty() && !updatedProdi.isEmpty()) {
            databaseReference.child("nick").setValue(updatedNick);
            databaseReference.child("email").setValue(updatedEmail);
            databaseReference.child("prodi").setValue(updatedProdi);

            Toast.makeText(profil.this, "Data berhasil diperbarui", Toast.LENGTH_SHORT).show();
            toggleEditMode(false); // Kembali ke mode tampilan
        } else {
            Toast.makeText(profil.this, "Semua data harus diisi", Toast.LENGTH_SHORT).show();
        }
    }

    // Fungsi untuk mengatur mode edit
    private void toggleEditMode(boolean enable) {
        if (enable) {
            // Mode edit: aktifkan EditText
            editTextNick.setEnabled(true);
            editTextEmail.setEnabled(true);
            editTextProdi.setEnabled(true);
            buttonEditProfile.setText("Simpan");
        } else {
            // Mode tampilan: nonaktifkan EditText
            editTextNick.setEnabled(false);
            editTextEmail.setEnabled(false);
            editTextProdi.setEnabled(false);
            buttonEditProfile.setText("Edit Profil");
        }
        isEditMode = enable;
    }

    // Fungsi untuk menghapus sesi pengguna
    private void clearSessionData() {
        // Hapus data sesi pengguna
        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear(); // Menghapus semua data sesi
        editor.apply();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (nimLogin != null && !nimLogin.isEmpty()) {
            loadDataFromFirebase(); // Memuat data terbaru dari Firebase
        }
    }
}
