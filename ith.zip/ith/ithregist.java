package com.example.ith;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.Firebase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ithregist extends AppCompatActivity {

    EditText inputname, inputnim, inputemail, inputpass, confrmpass;
    FirebaseDatabase database;
    DatabaseReference reference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ithregist);

        inputname = findViewById(R.id.inputname);
        inputnim = findViewById(R.id.inputnim);
        inputemail = findViewById(R.id.inputemail);
        inputpass = findViewById(R.id.inputpass);
        confrmpass = findViewById(R.id.confrmpass);

        Button btn_register = findViewById(R.id.button);
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String nama, nim, email, pass, conf_pass;
                nama = String.valueOf(inputname.getText());
                nim = String.valueOf(inputnim.getText());
                email = String.valueOf(inputemail.getText());
                pass = String.valueOf(inputpass.getText());
                conf_pass = String.valueOf(confrmpass.getText());

                // Validasi input
                if (TextUtils.isEmpty(nama)){
                    inputname.setError("Masukkan Nama");
                    inputname.requestFocus();
                    return;
                }
                if (TextUtils.isEmpty(nim)){
                    inputnim.setError("Masukkan Nim");
                    inputnim.requestFocus();
                    return;
                }
                if (TextUtils.isEmpty(email)){
                    inputemail.setError("Masukkan Email");
                    inputemail.requestFocus();
                    return;
                }
                if (TextUtils.isEmpty(pass)){
                    inputpass.setError("Masukkan Password");
                    inputpass.requestFocus();
                    return;
                }
                if (TextUtils.isEmpty(conf_pass)){
                    confrmpass.setError("Masukkan Password");
                    confrmpass.requestFocus();
                    return;
                }
                if (!pass.equals(conf_pass)) {
                    confrmpass.setError("Password tidak cocok");
                    confrmpass.requestFocus();
                    return;
                }

                // Firebase
                database = FirebaseDatabase.getInstance();
                reference = database.getReference("/users/mahasiswa");

                // Helper class
                HelperClass helperClass = new HelperClass(nama, nim, email, pass, conf_pass);
                reference.child(nim).setValue(helperClass).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Tampilkan pesan bahwa registrasi telah berhasil
                        Toast.makeText(ithregist.this, "Registrasi Berhasil", Toast.LENGTH_SHORT).show();

                        // Kirim NIM dan alihkan ke halaman login
                        Intent intent = new Intent(ithregist.this, ITHRegis.class);
                        intent.putExtra("nim_user", nim);  // Kirim NIM yang benar
                        startActivity(intent);
                    } else {
                        Toast.makeText(ithregist.this, "Registrasi Gagal", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });


        //        klik Tombol masuk
        TextView login2 = findViewById(R.id.login2);
        login2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                startActivity(new Intent(ithregist.this, ITHRegis.class));
            }
        });

        //        klik Tombol masuk

        ImageView arrow1 = findViewById(R.id.arrow);
        arrow1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                startActivity(new Intent(ithregist.this, MainActivity.class));
            }
        });
    }
}