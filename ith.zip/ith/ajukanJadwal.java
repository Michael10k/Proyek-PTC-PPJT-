package com.example.ith;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ajukanJadwal extends AppCompatActivity {

    private EditText namaJadwalEditText, idDosenEditText, ajukanJadwalEditText;
    private TextView bimbinganProyek, ajukanMasalah, konsultasi, setorTugas;
    private String selectedMeetingType = "";
    private String nimLogin; // Variable to hold the NIM
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajukan_jadwal);

        nimLogin = getIntent().getStringExtra("nimLogin");

        if (nimLogin == null || nimLogin.isEmpty()) {
            Toast.makeText(this, "NIM tidak ditemukan", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        // Initialize Firebase Database reference
        databaseReference = FirebaseDatabase.getInstance().getReference("jadwal");

        // Initialize the EditText fields
        namaJadwalEditText = findViewById(R.id.nama_jadwal);
        idDosenEditText = findViewById(R.id.id_dosen);
        ajukanJadwalEditText = findViewById(R.id.ajukan_jadwal);

        // Initialize TextViews for meeting types
        bimbinganProyek = findViewById(R.id.bimbingan_proyek);
        ajukanMasalah = findViewById(R.id.ajukanMasalah);
        konsultasi = findViewById(R.id.konsultasi);
        setorTugas = findViewById(R.id.setor_Tugas);

        // Set click listeners for meeting type selection
        bimbinganProyek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedMeetingType = "Bimbingan Proyek";
            }
        });

        ajukanMasalah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedMeetingType = "Ajukan Masalah";
            }
        });

        konsultasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedMeetingType = "Konsultasi";
            }
        });

        setorTugas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedMeetingType = "Setor Tugas";
            }
        });

        // Set click listener on the "Ajukan" button
        findViewById(R.id.button_ajukan).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the text from the EditText fields
                String namaKlp = namaJadwalEditText.getText().toString().trim();
                String idDosen = idDosenEditText.getText().toString().trim();
                String deskripsi = ajukanJadwalEditText.getText().toString().trim();

                // Check if any field is empty or if no meeting type is selected
                if (namaKlp.isEmpty() || idDosen.isEmpty() || deskripsi.isEmpty() || selectedMeetingType.isEmpty()) {
                    Toast.makeText(ajukanJadwal.this, "Semua kolom harus diisi dan tipe pertemuan harus dipilih", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Create a unique key for the new jadwal entry
                String key = databaseReference.push().getKey();

                // Create a new Jadwal object
                Jadwal jadwal = new Jadwal(nimLogin, namaKlp, deskripsi, idDosen, selectedMeetingType);

                // Save the new jadwal to Firebase Database
                if (key != null) {
                    databaseReference.child(key).setValue(jadwal)
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful()) {
                                    // Success
                                    Toast.makeText(ajukanJadwal.this, "Jadwal berhasil diajukan", Toast.LENGTH_SHORT).show();
                                    // Optionally, clear the input fields
                                    namaJadwalEditText.setText("");
                                    idDosenEditText.setText("");
                                    ajukanJadwalEditText.setText("");
                                    selectedMeetingType = ""; // Reset the selected meeting type
                                } else {
                                    // Failure
                                    Toast.makeText(ajukanJadwal.this, "Gagal mengajukan jadwal", Toast.LENGTH_SHORT).show();
                                }
                            });
                }
            }
        });
    }

    // Jadwal model class with meeting type and NIM
    public static class Jadwal {
        public String nimLogin;
        public String namaKlp;
        public String deskripsi;
        public String idDosen;
        public String tipePertemuan; // Add the meeting type field

        public Jadwal() {
            // Default constructor required for Firebase
        }

        public Jadwal(String nimLogin, String namaKlp, String deskripsi, String idDosen, String tipePertemuan) {
            this.nimLogin = nimLogin;
            this.namaKlp = namaKlp;
            this.deskripsi = deskripsi;
            this.idDosen = idDosen;
            this.tipePertemuan = tipePertemuan;
        }
    }
}
